﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using MySql.Data.MySqlClient;

namespace prj_prosante
{
    public partial class FrmVisiteSaisir : Form
    {
        public FrmVisiteSaisir()
        {
            InitializeComponent();
        }

        private void btnAjouter_Click(object sender, EventArgs e)
        {

            string[] visiteurSplit = cbVisiteur.Text.Split(' ');
            string MatVisiteur = "";

            foreach (Visiteur leVisiteur in Globale.lesVisiteurs)
            {
                if (cbVisiteur.Text == leVisiteur.getNom() + ' ' + leVisiteur.getPrenom())
                {
                    MatVisiteur = leVisiteur.getMatricule();

                }
            }


            DateTime date = monthCalendar1.SelectionStart;
            int heure = int.Parse(nudHeure.Value.ToString()) * 60;
            int duree = heure + int.Parse(nudMinutes.Value.ToString());
            string[] professionnelSplit = cbProfessionnel.Text.Split(' ');
            Visite laVisite = new Visite(date, (int)udNbProduitsRetenus.Value, (int)udNbProduitsPresentes.Value, (string)MatVisiteur, (string)professionnelSplit[0], (string)professionnelSplit[1], (int)nudSatisfaction.Value, (int)duree);
            Globale.lesVisites.Add(laVisite);

            string newDate = DateTime.Parse(laVisite.getDateVisiteAffichage()).Year.ToString() + "-" + DateTime.Parse(laVisite.getDateVisiteAffichage()).Month.ToString() + "-" + DateTime.Parse(laVisite.getDateVisiteAffichage()).Day.ToString();

            string chaineDeconnexion = "SERVER=localhost;" + "PORT=3306;" + "DATABASE=prosante_v1;" + "USER ID=root;" + "PASSWORD=;";
            MySqlConnection connection = new MySqlConnection(chaineDeconnexion);

            MySqlCommand maCommande = connection.CreateCommand();
            MySqlDataReader maLigne;


            maCommande = connection.CreateCommand();
            maCommande.CommandText = $"INSERT INTO tb_visite (dateVisite, nbProduitsPresentes, nbProduitsRetenus,matriculeVisiteur,nomPro,prenomPro,vst_numSatisfaction, vst_dureeMinute)  VALUES ('{newDate}', '{udNbProduitsRetenus.Value }','{udNbProduitsPresentes.Value }','{MatVisiteur }','{ professionnelSplit[0]} ','{ professionnelSplit[1] } ','{nudSatisfaction.Value}','{duree}')";
            connection.Open();
            maLigne = maCommande.ExecuteReader();

            connection.Close();
            MessageBox.Show("La visite a bien été ajoutée", "Information", MessageBoxButtons.OK, MessageBoxIcon.Information);



        }

        private void FrmVisiteSaisir_Load(object sender, EventArgs e)
        {
            foreach (Visiteur leVisiteur in Globale.lesVisiteurs)
            {
                cbVisiteur.Items.Add(leVisiteur.getNom() + ' ' + leVisiteur.getPrenom());
            }

            foreach (Professionnel lePro in Globale.lesProfessionnels)
            {
                cbProfessionnel.Items.Add(lePro.getNomPro() + ' ' + lePro.getPrenomPro());
            }
        }

        private void btnFermer_Click(object sender, EventArgs e)
        {
            this.Hide();
        }
    }
}
