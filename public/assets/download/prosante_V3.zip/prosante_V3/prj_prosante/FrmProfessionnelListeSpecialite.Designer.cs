﻿namespace prj_prosante
{
    partial class FrmProfessionnelListeSpecialite
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(FrmProfessionnelListeSpecialite));
            this.tbSpecialiteProfessionnel = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.btnFermer = new System.Windows.Forms.Button();
            this.btnRechercher = new System.Windows.Forms.Button();
            this.lvProfessionnelSpe = new System.Windows.Forms.ListView();
            this.col = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader2 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader1 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader3 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.SuspendLayout();
            // 
            // tbSpecialiteProfessionnel
            // 
            this.tbSpecialiteProfessionnel.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbSpecialiteProfessionnel.Location = new System.Drawing.Point(345, 30);
            this.tbSpecialiteProfessionnel.Margin = new System.Windows.Forms.Padding(4);
            this.tbSpecialiteProfessionnel.Name = "tbSpecialiteProfessionnel";
            this.tbSpecialiteProfessionnel.Size = new System.Drawing.Size(231, 26);
            this.tbSpecialiteProfessionnel.TabIndex = 15;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(116, 33);
            this.label3.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(209, 20);
            this.label3.TabIndex = 14;
            this.label3.Text = "Saisir la spécialité voulue :";
            // 
            // btnFermer
            // 
            this.btnFermer.BackColor = System.Drawing.Color.LightSteelBlue;
            this.btnFermer.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnFermer.Image = ((System.Drawing.Image)(resources.GetObject("btnFermer.Image")));
            this.btnFermer.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnFermer.Location = new System.Drawing.Point(375, 492);
            this.btnFermer.Margin = new System.Windows.Forms.Padding(4);
            this.btnFermer.Name = "btnFermer";
            this.btnFermer.Size = new System.Drawing.Size(203, 55);
            this.btnFermer.TabIndex = 17;
            this.btnFermer.Text = "&Fermer";
            this.btnFermer.UseVisualStyleBackColor = false;
            this.btnFermer.Click += new System.EventHandler(this.btnFermer_Click);
            // 
            // btnRechercher
            // 
            this.btnRechercher.BackColor = System.Drawing.Color.LightSteelBlue;
            this.btnRechercher.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnRechercher.Image = ((System.Drawing.Image)(resources.GetObject("btnRechercher.Image")));
            this.btnRechercher.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnRechercher.Location = new System.Drawing.Point(645, 15);
            this.btnRechercher.Margin = new System.Windows.Forms.Padding(4);
            this.btnRechercher.Name = "btnRechercher";
            this.btnRechercher.Size = new System.Drawing.Size(203, 55);
            this.btnRechercher.TabIndex = 18;
            this.btnRechercher.Text = "&Rechercher";
            this.btnRechercher.UseVisualStyleBackColor = false;
            this.btnRechercher.Click += new System.EventHandler(this.btnRechercher_Click);
            // 
            // lvProfessionnelSpe
            // 
            this.lvProfessionnelSpe.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.col,
            this.columnHeader2,
            this.columnHeader1,
            this.columnHeader3});
            this.lvProfessionnelSpe.HideSelection = false;
            this.lvProfessionnelSpe.Location = new System.Drawing.Point(235, 119);
            this.lvProfessionnelSpe.Margin = new System.Windows.Forms.Padding(4);
            this.lvProfessionnelSpe.Name = "lvProfessionnelSpe";
            this.lvProfessionnelSpe.Size = new System.Drawing.Size(451, 330);
            this.lvProfessionnelSpe.TabIndex = 19;
            this.lvProfessionnelSpe.UseCompatibleStateImageBehavior = false;
            this.lvProfessionnelSpe.View = System.Windows.Forms.View.Details;
            // 
            // col
            // 
            this.col.Text = "Nom professionnel";
            // 
            // columnHeader2
            // 
            this.columnHeader2.Text = "Prenom professionnel";
            this.columnHeader2.Width = 139;
            // 
            // columnHeader1
            // 
            this.columnHeader1.Text = "Ville professionnel";
            // 
            // columnHeader3
            // 
            this.columnHeader3.Text = "Année expérience professionnel";
            // 
            // FrmProfessionnelListeSpecialite
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1309, 699);
            this.Controls.Add(this.lvProfessionnelSpe);
            this.Controls.Add(this.btnRechercher);
            this.Controls.Add(this.btnFermer);
            this.Controls.Add(this.tbSpecialiteProfessionnel);
            this.Controls.Add(this.label3);
            this.Margin = new System.Windows.Forms.Padding(4);
            this.Name = "FrmProfessionnelListeSpecialite";
            this.Text = "Liste des professionnels par spécialité";
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            this.Load += new System.EventHandler(this.FrmProfessionnelListeSpecialite_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox tbSpecialiteProfessionnel;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Button btnFermer;
        private System.Windows.Forms.Button btnRechercher;
        private System.Windows.Forms.ListView lvProfessionnelSpe;
        private System.Windows.Forms.ColumnHeader col;
        private System.Windows.Forms.ColumnHeader columnHeader2;
        private System.Windows.Forms.ColumnHeader columnHeader1;
        private System.Windows.Forms.ColumnHeader columnHeader3;
    }
}