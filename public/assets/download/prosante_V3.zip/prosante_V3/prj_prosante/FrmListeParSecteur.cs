﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data.MySqlClient;

namespace prj_prosante
{
    public partial class FrmListeParSecteur : Form
    {
        public FrmListeParSecteur()
        {
            InitializeComponent();
        }

        private void btFermer_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void btnRechercher_Click(object sender, EventArgs e)
        {
            lvParSecteur.Items.Clear();
            foreach(Visiteur unVisiteur in Globale.lesVisiteurs)
            {
                if(cbParSecteur.Text == unVisiteur.getSecteur())
                {
                    ListViewItem laLigne = new ListViewItem();
                    laLigne.Text = unVisiteur.getMatricule();
                    laLigne.SubItems.Add(unVisiteur.getNom());
                    laLigne.SubItems.Add(unVisiteur.getPrenom());
                    laLigne.SubItems.Add(unVisiteur.getNumTelPort());
                    laLigne.SubItems.Add(unVisiteur.getSecteur());
                    lvParSecteur.Items.Add(laLigne);
                }
            }
        }

        private void FrmListeParSecteur_Load(object sender, EventArgs e)
        {
            //Pour remplir la combobox

            string chaineDeconnexion = "SERVER=localhost;" + "PORT=3306;" + "DATABASE=prosante_v1;" + "USER ID=root;" + "PASSWORD=;";
            MySqlConnection connection = new MySqlConnection(chaineDeconnexion);

            MySqlCommand maCommande = connection.CreateCommand();
            MySqlDataReader maLigne;
            maCommande.CommandText = "SELECT distinct secteurVisiteur from tb_visiteur";
            connection.Open();
            maLigne = maCommande.ExecuteReader();
            string[] valeurColonnes = new string[1];
            while (maLigne.Read())
            {

                for (int i = 0; i < maLigne.FieldCount; i++) valeurColonnes[i] = maLigne.GetValue(i).ToString();
                string secteur = valeurColonnes[0];
                cbParSecteur.Items.Add(valeurColonnes[0]);
            }
        }
    }
}
