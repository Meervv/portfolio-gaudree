﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace prj_prosante
{
    public partial class FrmVisiteStatistiques : Form
    {
        public FrmVisiteStatistiques()
        {
            InitializeComponent();
        }

        private void FrmVisiteStatistiques_Load(object sender, EventArgs e)
        {
            foreach (Visiteur leVisiteur in Globale.lesVisiteurs)
            {
                cbVisiteur.Items.Add(leVisiteur.getNom() + ' ' + leVisiteur.getPrenom());
            }

            foreach (Professionnel lePro in Globale.lesProfessionnels)
            {
                cbProfessionnel.Items.Add(lePro.getNomPro() + ' ' + lePro.getPrenomPro());
            }
            int NbTotalProduitPres = 0;
            int NbTotalProduitRet = 0;
            Single tpsMoyen = 0;
            int i = 0;
            foreach (Visite laVisite in Globale.lesVisites)
            {
                tbNbTotalVisites.Text = Globale.lesVisites.Count.ToString();
                NbTotalProduitPres = NbTotalProduitPres + laVisite.getNbProduitsPresentes();
                NbTotalProduitRet = NbTotalProduitRet + laVisite.getNbProduitsRetenus();
                tpsMoyen = laVisite.getDuree() + tpsMoyen;
                i += 1;
                
            }
            Single tpsMoyenFinale = tpsMoyen / i;
            tbTpsMoyen.Text = tpsMoyenFinale.ToString("00.00");
            tbNbProdPres.Text = NbTotalProduitPres.ToString();
            tbNbProdRetenu.Text = NbTotalProduitRet.ToString() ;
            Single pourcProd =   100*Single.Parse(tbNbProdRetenu.Text) / Single.Parse(tbNbProdPres.Text);
            tbPourcProdRetenu.Text = pourcProd.ToString("00.00");

            Single NoteSatis = 0;
            int y = 0;
            foreach (Satisfaction laSatisfaction in Globale.lesSatisfactions)
            {
                NoteSatis = NoteSatis + laSatisfaction.getSatisfaction();
                y += 1;
            }
            NoteSatis = NoteSatis / y;
            tbNoteMoyenne.Text = NoteSatis.ToString("00.00");



        }

        private void btnFermer_Click(object sender, EventArgs e)
        {
            this.Hide();
        }

        private void btnAfficherNbVisitesVisiteur_Click(object sender, EventArgs e)
        {
            tbNbVisitesVisiteur.Clear();
            string[] visiteurSplit = cbVisiteur.Text.Split(' ');

            int cmpt = 0;
            foreach (Visiteur leVisiteur in Globale.lesVisiteurs)
            {
                if (leVisiteur.getNom() == visiteurSplit[0])
                {
                    foreach (Visite laVisite in Globale.lesVisites)
                    {
                        if (leVisiteur.getMatricule() == laVisite.getMatVisiteur())
                        {
                            cmpt += 1;

                        }

                    }
                }
            }
            tbNbVisitesVisiteur.Text = cmpt.ToString();
        }

        private void btnAfficherNbVisitesProfessionnel_Click(object sender, EventArgs e)
        {
            tbNbVisitesProfessionnel.Clear();
            int cmpt = 0;
            foreach (Visite laVisite in Globale.lesVisites)
            {
                if (cbProfessionnel.Text == laVisite.getPro() )
                {
                    cmpt += 1;
                }

            }
            tbNbVisitesProfessionnel.Text = cmpt.ToString();
        }

        private void btnAfficherNbVisitesSpecialite_Click(object sender, EventArgs e)
        {
            tbNbVisitesSpecialite.Clear();

            int cmpt = 0;
            foreach (Professionnel leProfessionnel in Globale.lesProfessionnels)
            {
                if (leProfessionnel.getSpecialite() == tbSpecialite.Text)
                {
                    foreach (Visite laVisite in Globale.lesVisites)
                    {
                        if (leProfessionnel.getNomPro() + ' ' + leProfessionnel.getPrenomPro() == laVisite.getPro())
                        {
                            cmpt += 1;

                        }

                    }
                }
            }
            tbNbVisitesSpecialite.Text = cmpt.ToString();
        }

        private void label10_Click(object sender, EventArgs e)
        {

        }

        private void groupBox4_Enter(object sender, EventArgs e)
        {

        }
    }
}
