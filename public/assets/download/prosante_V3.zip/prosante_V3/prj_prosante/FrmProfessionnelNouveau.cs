﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using MySql.Data.MySqlClient;

namespace prj_prosante
{
    public partial class FrmProfessionnelNouveau : Form
    {
        public FrmProfessionnelNouveau()
        {
            InitializeComponent();
        }


        private void btnAjouter_Click(object sender, EventArgs e)
        {
            Professionnel leProfessionnel = new Professionnel(tbNomProfessionnel.Text.ToUpper(), tbPrenomProfessionnel.Text, tbSpecialiteProfessionnel.Text,
                tbVille.Text, tbAnneeExp.Text);
            Globale.lesProfessionnels.Add(leProfessionnel);

            string chaineDeconnexion = "SERVER=localhost;" + "PORT=3306;" + "DATABASE=prosante_v1;" + "USER ID=root;" + "PASSWORD=;";

            MySqlConnection connection = new MySqlConnection(chaineDeconnexion);

            MySqlCommand maCommande = connection.CreateCommand();
            MySqlDataReader maLigne;

            maCommande.CommandText = $"INSERT INTO TB_PROFESSIONNEL (nomPro, prenomPro, specialitePro, villePro, anneeExpPro) VALUES ('{tbNomProfessionnel.Text}','{tbPrenomProfessionnel.Text}', '{tbSpecialiteProfessionnel.Text}', '{tbVille.Text}', '{tbAnneeExp}')";
            connection.Open();
            maLigne = maCommande.ExecuteReader();
            while (maLigne.Read())
            {
                string[] valeurColonnes = new string[3];
                for (int i = 0; i < maLigne.FieldCount; i++) valeurColonnes[i] = maLigne.GetValue(i).ToString();

                string nom = valeurColonnes[0];
                string prenom = valeurColonnes[1];
                string specialite = valeurColonnes[2];

                //ajout des 2 nouvelles info des professionnels

                string ville = valeurColonnes[3];
                string anneeExp = valeurColonnes[4];

                Professionnel lePro = new Professionnel(nom, prenom, specialite, ville, anneeExp);
                Globale.lesProfessionnels.Add(leProfessionnel);
            }
            connection.Close();


            MessageBox.Show("Le professionnel a bien été créé", "Information", MessageBoxButtons.OK, MessageBoxIcon.Information);

        }

        private void FrmProfessionnelNouveau_Load(object sender, EventArgs e)
        {

        }

        private void btnFermer_Click(object sender, EventArgs e)
        {
            this.Hide();
        }
    }
}
