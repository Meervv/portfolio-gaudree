﻿namespace prj_prosante
{
    partial class FrmVisiteurListe
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(FrmVisiteurListe));
            this.btFermer = new System.Windows.Forms.Button();
            this.lvVisiteurListe = new System.Windows.Forms.ListView();
            this.columnHeader1 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader2 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader3 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader4 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.Secteur = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.SuspendLayout();
            // 
            // btFermer
            // 
            this.btFermer.BackColor = System.Drawing.Color.LightSteelBlue;
            this.btFermer.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btFermer.Image = ((System.Drawing.Image)(resources.GetObject("btFermer.Image")));
            this.btFermer.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btFermer.Location = new System.Drawing.Point(982, 369);
            this.btFermer.Margin = new System.Windows.Forms.Padding(4);
            this.btFermer.Name = "btFermer";
            this.btFermer.Size = new System.Drawing.Size(203, 55);
            this.btFermer.TabIndex = 18;
            this.btFermer.Text = "&Fermer";
            this.btFermer.UseVisualStyleBackColor = false;
            this.btFermer.Click += new System.EventHandler(this.btFermer_Click);
            // 
            // lvVisiteurListe
            // 
            this.lvVisiteurListe.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.columnHeader1,
            this.columnHeader2,
            this.columnHeader3,
            this.columnHeader4,
            this.Secteur});
            this.lvVisiteurListe.HideSelection = false;
            this.lvVisiteurListe.Location = new System.Drawing.Point(145, 41);
            this.lvVisiteurListe.Margin = new System.Windows.Forms.Padding(4);
            this.lvVisiteurListe.Name = "lvVisiteurListe";
            this.lvVisiteurListe.Size = new System.Drawing.Size(753, 515);
            this.lvVisiteurListe.TabIndex = 17;
            this.lvVisiteurListe.UseCompatibleStateImageBehavior = false;
            this.lvVisiteurListe.View = System.Windows.Forms.View.Details;
            // 
            // columnHeader1
            // 
            this.columnHeader1.Text = "Matricule";
            this.columnHeader1.Width = 100;
            // 
            // columnHeader2
            // 
            this.columnHeader2.Text = "Nom";
            this.columnHeader2.Width = 200;
            // 
            // columnHeader3
            // 
            this.columnHeader3.Text = "Prenom";
            this.columnHeader3.Width = 200;
            // 
            // columnHeader4
            // 
            this.columnHeader4.Text = "N° Tel Portable";
            this.columnHeader4.Width = 117;
            // 
            // Secteur
            // 
            this.Secteur.Text = "Secteur";
            // 
            // FrmVisiteurListe
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1443, 779);
            this.Controls.Add(this.btFermer);
            this.Controls.Add(this.lvVisiteurListe);
            this.Margin = new System.Windows.Forms.Padding(4);
            this.Name = "FrmVisiteurListe";
            this.Text = "Liste des visiteurs";
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            this.Load += new System.EventHandler(this.FrmVisiteurListe_Load);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button btFermer;
        private System.Windows.Forms.ListView lvVisiteurListe;
        private System.Windows.Forms.ColumnHeader columnHeader1;
        private System.Windows.Forms.ColumnHeader columnHeader2;
        private System.Windows.Forms.ColumnHeader columnHeader3;
        private System.Windows.Forms.ColumnHeader columnHeader4;
        private System.Windows.Forms.ColumnHeader Secteur;
    }
}