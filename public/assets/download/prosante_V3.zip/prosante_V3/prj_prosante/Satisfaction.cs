﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace prj_prosante
{
    class Satisfaction
    {
        private int satisfaction;
        private string libSatisfaction;

        public Satisfaction(int laSatisfaction, string leLibSatisfaction)
        {
            this.satisfaction = laSatisfaction;
            this.libSatisfaction = leLibSatisfaction;
        }

        public int getSatisfaction() { return this.satisfaction; }
        public string getLibSatisfaction() { return this.libSatisfaction; }
    }
}
