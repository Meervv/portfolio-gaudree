﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace prj_prosante
{
    public partial class FrmProfessionnelListeSpecialite : Form
    {
        public FrmProfessionnelListeSpecialite()
        {
            InitializeComponent();
        }

        private void btnRechercher_Click(object sender, EventArgs e)
        {
            foreach (Professionnel leProfessionnel in Globale.lesProfessionnels)
            {
                if (tbSpecialiteProfessionnel.Text == leProfessionnel.getSpecialite())
                {
                    ListViewItem laLigne = new ListViewItem();
                    laLigne.Text = leProfessionnel.getNomPro();
                    laLigne.SubItems.Add(leProfessionnel.getPrenomPro());
                    //ajout des 2 nouvelles colonnes
                    laLigne.SubItems.Add(leProfessionnel.getVille());
                    laLigne.SubItems.Add(leProfessionnel.getAnneeExp());
                    lvProfessionnelSpe.Items.Add(laLigne);
                }
            }
        }

        private void FrmProfessionnelListeSpecialite_Load(object sender, EventArgs e)
        {

        }

        private void btnFermer_Click(object sender, EventArgs e)
        {
            this.Hide();
        }
    }
}
