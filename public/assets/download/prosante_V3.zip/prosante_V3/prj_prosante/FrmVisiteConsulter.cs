﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace prj_prosante
{
    public partial class FrmVisiteConsulter : Form
    {
        public FrmVisiteConsulter()
        {
            InitializeComponent();
        }

        private void FrmVisiteConsulter_Load(object sender, EventArgs e)
        {
            foreach (Visite laVisite in Globale.lesVisites)
            {
                ListViewItem laLigne = new ListViewItem();

                laLigne.Text = laVisite.getNumVisite().ToString();
                laLigne.SubItems.Add(laVisite.getDateVisiteAffichage());
                laLigne.SubItems.Add(laVisite.getMatVisiteur());
                laLigne.SubItems.Add(laVisite.getPro());
                laLigne.SubItems.Add(laVisite.getNbProduitsPresentes().ToString());
                laLigne.SubItems.Add(laVisite.getNbProduitsRetenus().ToString());
                Boolean trouve = false;
                Satisfaction uneSatisfaction = null;
                int idx = 0;
                while (idx < Globale.lesSatisfactions.Count && !trouve)
                {
                    uneSatisfaction = Globale.lesSatisfactions.ElementAt(idx);
                    if (laVisite.getSatisfaction() == uneSatisfaction.getSatisfaction())
                    {
                        laLigne.SubItems.Add(uneSatisfaction.getLibSatisfaction());
                        trouve = true;
                    }
                    else
                        idx += 1;
                }
                laLigne.SubItems.Add(laVisite.getDuree().ToString());
                lvVisiteToutes.Items.Add(laLigne);

            }
        }

        private void btnFermer_Click(object sender, EventArgs e)
        {
            this.Hide();
        }
    }
}
