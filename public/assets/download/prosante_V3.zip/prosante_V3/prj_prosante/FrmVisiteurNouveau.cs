﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using MySql.Data.MySqlClient;

namespace prj_prosante
{
    public partial class FrmVisiteurNouveau : Form
    {
        public FrmVisiteurNouveau()
        {
            InitializeComponent();
        }



        private void btnAjouter_Click_1(object sender, EventArgs e)
        {
        }
        private void btnFermer_Click_1(object sender, EventArgs e)
        {
            this.Hide();
        }

        private void FrmVisiteurNouveau_Load(object sender, EventArgs e)
        {
            string chaineDeconnexion = "SERVER=localhost;" + "PORT=3306;" + "DATABASE=prosante_v1;" + "USER ID=root;" + "PASSWORD=;";
            MySqlConnection connection = new MySqlConnection(chaineDeconnexion);

            MySqlCommand maCommande = connection.CreateCommand();
            MySqlDataReader maLigne;
            maCommande.CommandText = "SELECt distinct secteurVisiteur from tb_visiteur";
            connection.Open();
            maLigne = maCommande.ExecuteReader();
            string[] valeurColonnes = new string[1];
            while (maLigne.Read())
            {

                for (int i = 0; i < maLigne.FieldCount; i++) valeurColonnes[i] = maLigne.GetValue(i).ToString();
                string secteur = valeurColonnes[0];
                cbSecteur.Items.Add(valeurColonnes[0]);
            }
        }

        private void btnAjouter_Click(object sender, EventArgs e)
        {
        }

        private void btnAjouter_Click_2(object sender, EventArgs e)
        {
                Visiteur leVisiteur = new Visiteur(tbMatriculeVisiteur.Text, tbNomVisiteur.Text, tbPrenomVisiteur.Text, tbTelPort.Text, cbSecteur.Text);
                Globale.lesVisiteurs.Add(leVisiteur);
                string chaineDeconnexion = "SERVER=localhost;" + "PORT=3306;" + "DATABASE=prosante_v1;" + "USER ID=root;" + "PASSWORD=;";
                MySqlConnection connection = new MySqlConnection(chaineDeconnexion);

                MySqlCommand maCommande = connection.CreateCommand();
                MySqlDataReader maLigne;
                maCommande.CommandText = $"INSERT INTO TB_VISITEUR(matriculeVisiteur, nomVisiteur, prenomVisiteur, telPortVisiteur, secteurVisiteur) VALUES('{tbMatriculeVisiteur.Text}','{tbNomVisiteur.Text}','{tbPrenomVisiteur.Text}','{tbTelPort.Text}','{cbSecteur.Text}')";
                connection.Open();
                maLigne = maCommande.ExecuteReader();
                while (maLigne.Read())
                {
                    string[] valeurColonnes = new string[5];
                    for (int i = 0; i < maLigne.FieldCount; i++) valeurColonnes[i] = maLigne.GetValue(i).ToString();

                    string matricule = valeurColonnes[0];
                    string nom = valeurColonnes[1];
                    string prenom = valeurColonnes[2];
                    string numTelPort = valeurColonnes[3];
                    string secteur = valeurColonnes[4];
                    Visiteur unVisiteur = new Visiteur(matricule, nom, prenom, numTelPort, secteur);
                    Globale.lesVisiteurs.Add(unVisiteur);
                }
                connection.Close();



                MessageBox.Show("Le visiteur a bien été ajouté", "Information", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
        }
    }
    
    

