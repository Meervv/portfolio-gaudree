﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace prj_prosante
{
    public partial class FrmVisiteurListe : Form
    {
        public FrmVisiteurListe()
        {
            InitializeComponent();
        }

        private void listView1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void FrmVisiteurListe_Load(object sender, EventArgs e)
        {
            foreach (Visiteur unVisiteur in Globale.lesVisiteurs)
            {

                ListViewItem laLigne = new ListViewItem();
                laLigne.Text = unVisiteur.getMatricule();
                laLigne.SubItems.Add(unVisiteur.getNom());
                laLigne.SubItems.Add(unVisiteur.getPrenom());
                laLigne.SubItems.Add(unVisiteur.getNumTelPort());
                laLigne.SubItems.Add(unVisiteur.getSecteur());
                lvVisiteurListe.Items.Add(laLigne);
            }
        }

        private void btFermer_Click(object sender, EventArgs e)
        {
            this.Hide();
        }
    }
}
