﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace prj_prosante
{
    class Visiteur
    {
        private string matricule;
        private string nom;
        private string prenom;
        private string numTelPort;
        private string secteur;

        public Visiteur(string unMatricule, string unNom, string unPrenom, string unNumTelPort, string unSecteur)
        {
            this.matricule = unMatricule; this.nom = unNom; this.prenom = unPrenom; this.numTelPort = unNumTelPort; this.secteur = unSecteur;
        }

        public string getMatricule() { return this.matricule; }
        public string getNom() { return this.nom; }
        public string getPrenom() { return this.prenom; }     
        public string getNumTelPort() { return this.numTelPort; }
        public string getSecteur() { return this.secteur; }
    }
}
