﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace prj_prosante
{
    class Globale
    {
        public static List<Visite> lesVisites;
        public static List<Visiteur> lesVisiteurs;
        public static List<Professionnel> lesProfessionnels;
        public static List<Satisfaction> lesSatisfactions;
    }
}
