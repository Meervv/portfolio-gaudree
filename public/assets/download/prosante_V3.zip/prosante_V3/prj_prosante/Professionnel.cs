﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace prj_prosante
{
    class Professionnel
    {
        private string nomPro;
        private string prenomPro;
        private string specialite;
        private string ville;
        private string anneeExp;

        public Professionnel(string unNomPro, string unPrenomPro, string uneSpec, string uneVille, string lesAnneeExp)
        {
            this.nomPro = unNomPro;
            this.prenomPro = unPrenomPro;
            this.specialite = uneSpec;
            this.ville = uneVille;
            this.anneeExp = lesAnneeExp;
        }

        public string getNomPro() { return this.nomPro; }
        public string getPrenomPro() { return this. prenomPro; }
        public string getSpecialite() { return this.specialite; }
        //ajout des getters
        public string getVille() { return this.ville; }

        public string getAnneeExp() { return this.anneeExp; }
        public void ChangerSpecialite(string unespec)
        {
            this.specialite = unespec;
        }
    }
}
