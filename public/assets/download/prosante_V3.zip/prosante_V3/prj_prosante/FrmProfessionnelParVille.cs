﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace prj_prosante
{
    public partial class FrmProfessionnelParVille : Form
    {
        public FrmProfessionnelParVille()
        {
            InitializeComponent();
        }

        private void FrmProfessionnelParVille_Load(object sender, EventArgs e)
        {
            foreach(Professionnel lePro in Globale.lesProfessionnels)
            {
                if (!cbPro.Items.Contains(lePro.getVille()))
                    cbPro.Items.Add(lePro.getVille());
            }
        }

        private void btnRechercher_Click(object sender, EventArgs e)
        {
            lvPro.Items.Clear();
            foreach(Professionnel lesPro in Globale.lesProfessionnels)
            {
                if (cbPro.Text == lesPro.getVille())
                {
                    ListViewItem ligne = new ListViewItem();
                    ligne.Text = lesPro.getNomPro();
                    ligne.SubItems.Add(lesPro.getPrenomPro());
                    ligne.SubItems.Add(lesPro.getAnneeExp());
                    lvPro.Items.Add(ligne);
                }
            }
        }
    }
}
