﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using MySql.Data.MySqlClient;

namespace prj_prosante
{
    public partial class FrmMenu : Form
    {
        private int childFormNumber = 0;

        public FrmMenu()
        {
            InitializeComponent();
        }

        private void ShowNewForm(object sender, EventArgs e)
        {
            Form childForm = new Form();
            childForm.MdiParent = this;
            childForm.Text = "Fenêtre " + childFormNumber++;
            childForm.Show();
        }

        private Visiteur rechercherVisiteurVisite(string matricule)
        {
            //recherche d'un visiteur connaissant son matricule
            Boolean trouve = false;
            int idx = 0;
            while (idx < Globale.lesVisiteurs.Count && !trouve)
            {
                if (Globale.lesVisiteurs[idx].getMatricule() == matricule)
                    trouve = true;
                else
                    idx++;
            }
            if (trouve) return Globale.lesVisiteurs[idx]; else return null;
        }

        private Professionnel rechercherProfessionnelVisite(string nom, string prenom)
        {
            //recherche d'un professionnel connaissant son nom et son prénom
            Boolean trouve = false;
            int idx = 0;
            while (idx < Globale.lesProfessionnels.Count && !trouve)
            {
                if (Globale.lesProfessionnels[idx].getNomPro() == nom)
                    trouve = true;
                else
                    idx++;
            }
            if (trouve) return Globale.lesProfessionnels[idx]; else return null;
        }

        private void OpenFile(object sender, EventArgs e)
        {
            //chargement des données de la base BD_ProSante_V1 dans les collections
            // --> lesVisiteurs
            Globale.lesVisiteurs = new List<Visiteur>() ;

            string chaineDeconnexion = "SERVER=localhost;" + "PORT=3306;" + "DATABASE=prosante_v1;" + "USER ID=root;" + "PASSWORD=;";
            MySqlConnection connection = new MySqlConnection(chaineDeconnexion);
            
            MySqlCommand maCommande = connection.CreateCommand();
            MySqlDataReader maLigne;
            maCommande.CommandText = "select * from tb_visiteur";
            connection.Open();
            maLigne = maCommande.ExecuteReader();
            while (maLigne.Read())
            {
                string[] valeurColonnes = new string[5];
                for (int i = 0; i < maLigne.FieldCount; i++) valeurColonnes[i] = maLigne.GetValue(i).ToString() ;

                string matricule = valeurColonnes[0];
                string nom = valeurColonnes[1];
                string prenom = valeurColonnes[2];
                string numTelPort = valeurColonnes[3];
                string secteur = valeurColonnes[4];
                Visiteur unVisiteur = new Visiteur(matricule, nom, prenom, numTelPort, secteur);
                Globale.lesVisiteurs.Add(unVisiteur);
            }
            connection.Close();

            // --> lesProfessionnels
            Globale.lesProfessionnels = new List<Professionnel>();

            maCommande = connection.CreateCommand();
            maCommande.CommandText = "select * from tb_professionnel";
            connection.Open();
            maLigne = maCommande.ExecuteReader();
            while (maLigne.Read())
            {
                string[] valeurColonnes = new string[5]; 
                for (int i = 0; i < maLigne.FieldCount; i++) valeurColonnes[i] = maLigne.GetValue(i).ToString();

                string nom = valeurColonnes[0];
                string prenom = valeurColonnes[1];
                string specialite = valeurColonnes[2];
                string ville = valeurColonnes[3];
                string anneeExp = valeurColonnes[4];
                Professionnel unProfessionnel = new Professionnel(nom, prenom, specialite, ville, anneeExp);
                Globale.lesProfessionnels.Add(unProfessionnel);
            }
            connection.Close();

            // --> lesVisites
            Globale.lesVisites = new List<Visite>();

            maCommande = connection.CreateCommand();
            maCommande.CommandText = "select * from tb_visite";
            connection.Open();
            maLigne = maCommande.ExecuteReader();
            while (maLigne.Read())
            {
                string[] valeurColonnes = new string[9];
                for (int i = 0; i < maLigne.FieldCount; i++) valeurColonnes[i] = maLigne.GetValue(i).ToString();
  
                int numero = int.Parse(valeurColonnes[0]);
                DateTime dateVisite = DateTime.Parse(valeurColonnes[1]);
                int nbProdPres = int.Parse(valeurColonnes[2]);
                int nbProdRet = int.Parse(valeurColonnes[3]);
                string matricule = valeurColonnes[4];
                string nom = valeurColonnes[5];
                string prenom = valeurColonnes[6];
                int satisfaction = int.Parse(valeurColonnes[7]);
                int duree = int.Parse(valeurColonnes[8]);

                Visiteur leVisiteur = rechercherVisiteurVisite(matricule);
                Professionnel leProfessionnel = rechercherProfessionnelVisite(nom, prenom);

                Visite uneVisite = new Visite(dateVisite, nbProdRet, nbProdPres, matricule, nom, prenom, satisfaction, duree);
                Globale.lesVisites.Add(uneVisite);
            
            }
            connection.Close();

            // Satisfaction
            Globale.lesSatisfactions = new List<Satisfaction>();

            maCommande = connection.CreateCommand();
            maCommande.CommandText = "select * from tb_satisfaction";
            connection.Open();
            maLigne = maCommande.ExecuteReader();
            while (maLigne.Read())
            {
                string[] valeurColonnes = new string[7];
                for (int i = 0; i < maLigne.FieldCount; i++) valeurColonnes[i] = maLigne.GetValue(i).ToString();

                int numero = int.Parse(valeurColonnes[0]);
                string libSatisfaction = valeurColonnes[1];


                Satisfaction uneSatisfaction = new Satisfaction(numero, libSatisfaction);
                Globale.lesSatisfactions.Add(uneSatisfaction);

            }
            connection.Close();

        }

        private void SaveAsToolStripMenuItem_Click(object sender, EventArgs e)
        {
            SaveFileDialog saveFileDialog = new SaveFileDialog();
            saveFileDialog.InitialDirectory = Environment.GetFolderPath(Environment.SpecialFolder.Personal);
            saveFileDialog.Filter = "Fichiers texte (*.txt)|*.txt|Tous les fichiers (*.*)|*.*";
            if (saveFileDialog.ShowDialog(this) == DialogResult.OK)
            {
                string FileName = saveFileDialog.FileName;
            }
        }

        private void ExitToolsStripMenuItem_Click(object sender, EventArgs e)
        {
            this.Close();
        }




       

        private void CloseAllToolStripMenuItem_Click(object sender, EventArgs e)
        {
            foreach (Form childForm in MdiChildren)
            {
                childForm.Close();
            }
        }

        private void visiteurNouveauOptionMenu_Click(object sender, EventArgs e)
        {
            FrmVisiteurNouveau maFenetre = new FrmVisiteurNouveau();
            maFenetre.MdiParent = this;
            maFenetre.Show();
        }

        private void visiteurListeOptionMenu_Click(object sender, EventArgs e)
        {
            FrmVisiteurListe maFenetre = new FrmVisiteurListe();
            maFenetre.MdiParent = this;
            maFenetre.Show();
        }

        private void professionnelNouveauOptionMenu_Click(object sender, EventArgs e)
        {
            FrmProfessionnelNouveau maFenetre = new FrmProfessionnelNouveau();
            maFenetre.MdiParent = this;
            maFenetre.Show();
        }

        private void professionnelListeTousOptionMenu_Click(object sender, EventArgs e)
        {
            FrmProfessionnelListeTous maFenetre = new FrmProfessionnelListeTous();
            maFenetre.MdiParent = this;
            maFenetre.Show();
        }

        private void professionnelListeSpecialiteOptionMenu_Click(object sender, EventArgs e)
        {
            FrmProfessionnelListeSpecialite maFenetre = new FrmProfessionnelListeSpecialite();
            maFenetre.MdiParent = this;
            maFenetre.Show();
        }

        private void visiteSaisirOptionMenu_Click(object sender, EventArgs e)
        {
            FrmVisiteSaisir maFenetre = new FrmVisiteSaisir();
            maFenetre.MdiParent = this;
            maFenetre.Show();
        }

        private void visiteConsulterOptionMenu_Click(object sender, EventArgs e)
        {
            FrmVisiteConsulter maFenetre = new FrmVisiteConsulter();
            maFenetre.MdiParent = this;
            maFenetre.Show();
        }

        private void visiteStatistiquesOptionMenu_Click(object sender, EventArgs e)
        {
            FrmVisiteStatistiques maFenetre = new FrmVisiteStatistiques();
            maFenetre.MdiParent = this;
            maFenetre.Show();
        }

        private void aboutToolStripMenuItem_Click(object sender, EventArgs e)
        {
            FrmAPropos maFenetre = new FrmAPropos();
            maFenetre.MdiParent = this;
            maFenetre.Show();
        }

        private void FrmMenu_Load(object sender, EventArgs e)
        {

        }

        private void toolStrip_ItemClicked(object sender, ToolStripItemClickedEventArgs e)
        {

        }

        private void parSecteurToolStripMenuItem_Click(object sender, EventArgs e)
        {
            FrmListeParSecteur maFenetre = new FrmListeParSecteur();
            maFenetre.MdiParent = this;
            maFenetre.Show();
        }

        private void parVilleToolStripMenuItem_Click(object sender, EventArgs e)
        {
            FrmProfessionnelParVille maFenetre = new FrmProfessionnelParVille();
            maFenetre.MdiParent = this;
            maFenetre.Show();
        }
    }
}
