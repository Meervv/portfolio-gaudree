﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace prj_prosante
{
    class Visite
    {
        private int numVisite;
        private DateTime dateVisite;
        private int nbProduitsPresentes;
        private int nbProduitsRetenus;
        private string matVisiteur;
        private string nomPro;
        private string prenomPro;
        private int satisfaction;
        private int duree;

        // C'est le constructeur de la classe viste, cela permet d'instancier une nouvelle visite
        public Visite(DateTime uneDateVisite, int unNbProduitsRetenus, int unNbProduitsPresentes, string leMatVisiteur, string leNomPro, string lePrenomPro, int laSatisfaction, int laDuree)
        {
            this.numVisite = Globale.lesVisites.Count;
            this.dateVisite = uneDateVisite;
            this.nbProduitsPresentes = unNbProduitsPresentes;
            this.nbProduitsRetenus = unNbProduitsRetenus;
            this.matVisiteur = leMatVisiteur;
            this.nomPro = leNomPro;
            this.prenomPro = lePrenomPro;
            this.satisfaction = laSatisfaction;
            this.duree = laDuree;
        }

        public int getDuree() { return this.duree; }
        public int getSatisfaction() { return this.satisfaction; }
        public string getMatVisiteur() { return this.matVisiteur; }
        public string getPro() { string Pro; Pro = this.nomPro + " " +  this.prenomPro; return Pro; }

        // Cela permet d'afficher le numéro des visite, cela va 
        public int getNumVisite() { return this.numVisite; }
        // Cela permet d'afficher la date de visite, cela va retourner une chaîne de caractère
        public String getDateVisiteAffichage() { return this.dateVisite.ToShortDateString(); }
        // Cela permet d'afficher le nombre de produit présenté lors de la visite, cela va retourner un nombre entier
        public int getNbProduitsPresentes() { return this.nbProduitsPresentes ; }
        // Cela permet d'afficher le nombre de produit retenus lors de la visite, Cela va retourner un nombre entier
        public int getNbProduitsRetenus() { return this.nbProduitsRetenus ; }


    }
}
